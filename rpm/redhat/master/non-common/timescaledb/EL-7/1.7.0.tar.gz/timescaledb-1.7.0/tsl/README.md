## TimescaleDB TsL Library ##

The TimescaleDB TsL library is licensed under the [Timescale License](LICENSE-TIMESCALE).


