DROP VIEW IF EXISTS timescaledb_information.continuous_aggregates;
